﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class MyGUI : MonoBehaviour
{
    //参数设置组件
    public GUISkin Myskin;
    public testLsystemGenerator1 MyLsystem;
    public string TreeAngel  = "";//先定义一个全局变量UserName
    public string StartChar = "";
    public string Myrules = "";//输入规则
    public string StartChar2 = "";
    public string Myrules2 = "";//输入规则
    //public string MyGenerateNum = "5";



    public float Mytime;
    //public float ThreeDisplay;
    //private bool ShowThreeD = false;
    public GameObject Tree;

    // Use this for initialization
    void Start()
    {
       
    }
    // Update is called once per frame

    ///
    /// 每当重绘时候都会执行这一个方法
    ///
    void OnGUI()
    {
        GUI.skin = Myskin;
        int Left = 50;//位置
        int Top = 205;
        //先绘制一个BOX来将我们在视觉上框起来，这里用到Rect这个坐标变量,框体是从左上角开始绘制的，因此这里的坐标也是左上角的坐标
        GUI.Box(new Rect(Left -15, Top - 10, 250, 250), "parameter settings");//Rect(x轴坐标，y轴坐标，宽度，高度)，Login就是标题的名称
        if (GUI.Button(new Rect(Left, Top + 250, 70, 20), "Start"))
        {
                Time.timeScale = 1;
                print("Button Check");
                GameObject.Find("Tree").GetComponent<testLsystemGenerator1>().enabled = true;
                // GUI.RepeatButton(new Rect(Left,Top + 60,100, 20), "RepeatButton");

        }
        if (GUI.Button(new Rect(Left + 80, Top + 250, 70, 20), "Stop"))
        {
                print("Stop Check");
                GameObject.Find("Tree").GetComponent<testLsystemGenerator1>().enabled = false;
                Time.timeScale = 0;

        }

        if (GUI.Button(new Rect(Left + 160, Top + 250, 70, 20), "Restart"))
        {
                print("Restart Now!");
                SceneManager.LoadScene(0);

        }

        GUI.Label(new Rect(Left, Top + 40, 100, 20), "StartCharacter1:");
        StartChar = GUI.TextField(new Rect(Left, Top + 60, 100, 20), StartChar, 15);
        Tree.GetComponent<testLsystemGenerator1>().axiom = StartChar;

        GUI.Label(new Rect(Left + 120, Top + 40, 100, 20), "Rule1:");
        Myrules = GUI.TextField(new Rect(Left + 120, Top + 60, 100, 20), Myrules, 40);
        Tree.GetComponent<testLsystemGenerator1>().myRules = Myrules;

        GUI.Label(new Rect(Left, Top + 80, 100, 20), "StartCharacter2:");
        StartChar2 = GUI.TextField(new Rect(Left, Top + 100, 100, 20), StartChar2, 15);
        Tree.GetComponent<testLsystemGenerator1>().axiom2 = StartChar2;

        GUI.Label(new Rect(Left + 120, Top + 80, 100, 20), "Rule2:");
        Myrules2 = GUI.TextField(new Rect(Left + 120, Top + 100, 100, 20), Myrules2, 40);
        Tree.GetComponent<testLsystemGenerator1>().myRules2 = Myrules2;


        GUI.Label(new Rect(Left, Top + 120, 100, 20), "Angel:");//Label文本的绘制
        TreeAngel = GUI.TextField(new Rect(Left, Top + 140, 100, 20),TreeAngel,25);//将使得返回值赋予给UserName
        float Myangel = float.Parse(TreeAngel);
        Tree.GetComponent<testLsystemGenerator1>().angle = Myangel;

        /*GUI.Label(new Rect(Left, Top + 160, 100, 20), "Generation:");//Label文本的绘制
        MyGenerateNum = GUI.TextField(new Rect(Left, Top + 180, 100, 20), MyGenerateNum, 25);//将使得返回值赋予给UserName
        float GenerateNumF =  float.Parse(MyGenerateNum);
        int GenerateNum = (int)GenerateNumF;
        Tree.GetComponent<testLsystemGenerator>().generatenum = GenerateNum;*/



        GUI.Label(new Rect(Left, Top + 200, 100, 20), "Growing Speed:");
        Mytime = GUI.HorizontalSlider(new Rect(50, 430, 100, 30), Mytime, 0.1f, 100);
        Tree.GetComponent<testLsystemGenerator1>().time = Mytime;

        GUI.Label(new Rect(Left + 120, Top + 200, 100, 20), "Show 3D:");
        //ThreeDisplay = GUI.HorizontalSlider(new Rect(50+120, 430, 100, 30),ThreeDisplay, 0.1f, 100);
        //Tree.GetComponent<testLsystemGenerator>().time = Mytime;


        //Toggle是一个开关变量，返回值为布尔型，因此这里要在全局定义一个bool变量
        //ShowThreeD = GUI.Toggle(new Rect(Left + 170, Top + 220, 50, 20), ShowThreeD, "Show 3D");
        //LoginRoot = GUI.Toggle(new Rect(Left + 50, Top + 240, 80, 20), !LoginRoot, "Manager");
    }
    void Update()
    {
     
        /*if (ShowThreeD == true)
        {
            GameObject.Find("Tree").GetComponent<Animation>().enabled = true;
            Debug.Log("It's a 3D");
        }*/
    }



}