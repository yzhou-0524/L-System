﻿using System.Collections;
using UnityEngine;

public class TransforInfor
{
    public Vector3 position;
    public Quaternion rotation;

}
