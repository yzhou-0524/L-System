﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LsystemGenerator : MonoBehaviour
{
   private string axiom = "F";
    private float angle;
    private string currentString;
    private Dictionary<char, string> rules = new Dictionary<char, string>();
    private Stack<TransforInfor> transformStack = new Stack<TransforInfor>();

    private float length;
    private bool isGenerating = false;
    private Color newColor;
    void Start()
    {

        newColor = new Color(0.62f,0.22f,0.09f,1f);
        rules.Add('F', "FF+[+F-F+F]-[-F+F-F]");
        currentString = axiom;
        length = 10f;
        angle = 25f;
        StartCoroutine(GenerateLSystem());

       /* Generate();
        Generate();
        Generate();
        Generate(); */

    }

    void Update()
    {
        
    }

    IEnumerator GenerateLSystem()
    {
        int count = 0;
        while (count < 5)
        {
            if (!isGenerating)
            {
                isGenerating = true;
                StartCoroutine(Generate());


            }
            else
            {
                yield return new WaitForSeconds(0.1f);

            }


        }
    }


   IEnumerator Generate()
    {
        length = length / 2f;
        string newString = "";
        char[] stringCharacters = currentString.ToCharArray();
        for (int i = 0; i< stringCharacters.Length; i++)
        {
            char currentCharacter = stringCharacters[i];

            if(rules.ContainsKey(currentCharacter))
            {
                newString += rules[currentCharacter];
            }
            else
            {
                newString += currentCharacter.ToString();
            }

            //newString += rules[currentCharacter];
        }
        currentString = newString;
        Debug.Log(currentString);

        for (int i = 0; i < stringCharacters.Length; i++)
        {
            char currentCharacter = stringCharacters[i];

            if (currentCharacter == 'F')//move forward
            {
                Vector3 initialPosition = transform.position;
                transform.Translate(Vector3.forward * length);
                Debug.DrawLine(initialPosition, transform.position, newColor, 1000f, false);
                yield return null;
            }
            else if (currentCharacter == '+')
            {
                transform.Rotate(Vector3.up * angle);
            }
            else if (currentCharacter == '-')
            {
                transform.Rotate(Vector3.up * -angle);
            }
            else if (currentCharacter == '[')
            {
                TransforInfor ti = new TransforInfor();
                ti.position = transform.position;
                ti.rotation = transform.rotation;
                transformStack.Push(ti);
                newColor = newColor = new Color(0.08f, 0.85f, 0.14f, 1f);
            }
            else if (currentCharacter == ']')
            {
                TransforInfor ti = transformStack.Pop();
                transform.position = ti.position;
                transform.rotation = ti.rotation;   
                newColor = new Color(0.62f, 0.22f, 0.09f, 1f);
            }
        }
        isGenerating = false;
    }
}
