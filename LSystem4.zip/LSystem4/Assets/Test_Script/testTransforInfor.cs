﻿using System.Collections;
using UnityEngine;

public class testTransforInfor
{
    public Vector3 position;
    public Quaternion rotation;
    
}
