﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class testLsystemGenerator1 : MonoBehaviour
{
    public string axiom;
    public string axiom2;
    public float angle;
    private string currentString;
    private string currentString2;
    public string myRules = "";
    public string myRules2 = "";
    public float speed;
    public float time;
    //public int generatenum;
    public Button Rotate;
    private Dictionary<char, string> rules = new Dictionary<char, string>();
    //private Dictionary<char, string> rules2 = new Dictionary<char, string>();
    private Stack<testTransforInfor> transformStack = new Stack<testTransforInfor>();

    private float length;
    //private bool isGenerating = false;
    //private Color newColor;
    public GameObject Tree;
    //public GameObject Tree2;
    public GameObject Leaf;
    public GameObject Branch;
    //public GameObject Branch2;

    //[Header("Colours")]
    //public MeshRenderer MyRenderer;
    void Start()
    {
        //axiom = "";
        rules.Add('X', myRules);
        rules.Add('F', myRules2);

        Tree = Branch;
        //Tree2 = Branch2;


        currentString = axiom;

        //currentString = axiom2;
        //rules.Add('X', myRules);

        //currentString2 = axiom2;
        length = 10f;
        //angle = 25.7f;
        time = 0.1f;


        Generate();
        Generate();
        Generate();
        Generate();
        //Generate();
       // Generate();


    }


    void Update()
    {
        speed = length / time;


    }

    /*IEnumerator GenerateLSystem()
    {

        int count = 0;

        while (count < 3)
        {
            if (!isGenerating)
            {
                isGenerating = true;
                StartCoroutine(Generate());


            }
            else
            {
                yield return new WaitForSeconds(speed);

            }


        }
    }
    */

   void Generate()
    {
        length = length / 2.5f;
        string newString = "";
        char[] stringCharacters = currentString.ToCharArray();
        //char[] stringCharacters2 = currentString2.ToCharArray();
        for (int i = 0; i< stringCharacters.Length; i++)
        {
            char currentCharacter = stringCharacters[i];
            if(rules.ContainsKey(currentCharacter) )
            {          
                newString += rules[currentCharacter];

            }

            else
            {
                newString += currentCharacter.ToString();

            }
            /*if (currentCharacter == 'X')
            {
                newString += myRules;
            }
            else if(currentCharacter == 'F')
            {
                newString += myRules2;
            }
            else
            {
                newString += currentCharacter.ToString();

            }*/

            currentString = newString;
            Debug.Log(currentString);
        }

        

        stringCharacters = currentString.ToCharArray();

        for (int i = 0; i < stringCharacters.Length; i++)
        {
            char currentCharacter = stringCharacters[i];
            

            if (currentCharacter == 'F')//move forward
            {

                Vector3 initialPosition = transform.position;
                 transform.Translate(Vector3.forward * length);
                GameObject gametree =Instantiate(Tree, initialPosition, transform.rotation);
                //GameObject gametree2 = Instantiate(Tree2, initialPosition, transform.rotation);

                /*GameObject obj = Instantiate(gametree);
                Quaternion rotations = Quaternion.identity;
                rotations.eulerAngles = new Vector3(0.0f, 50f, 0.0f);
                obj.transform.rotation = rotations;*/

                //Debug.DrawLine(initialPosition, transform.position, newColor, 1000f, false); Line Tree
               // yield return null;
            }


            else if (currentCharacter == '+')
            {
                
                transform.Rotate(Vector3.up * angle);
            }
            else if (currentCharacter == '-')
            {
                transform.Rotate(Vector3.up * -angle);
            }
            else if (currentCharacter == '[')
            {
                Tree = Leaf;
                testTransforInfor ti = new testTransforInfor();
                ti.position = transform.position;
                ti.rotation = transform.rotation;
                transformStack.Push(ti);

            }

            /*else if (currentCharacter == 'X')
            {

                //Vector3 initialPosition = transform.position;
                //yield return null;

            }*/

            else if (currentCharacter == ']')
            {
                Tree = Branch;
                testTransforInfor ti = transformStack.Pop();
                transform.position = ti.position;
                transform.rotation = ti.rotation;



            }

            else if (currentCharacter == '/')
            {

                Vector3 initialPosition = transform.position;
                transform.Translate(Vector3.forward * length);
                transform.Rotate(Vector3.left * angle);


            }

            else if (currentCharacter == '|')
            {
                Vector3 initialPosition = transform.position;
                transform.Translate(Vector3.forward * length);
                transform.Rotate(Vector3.right * angle);


            }


        }
        //isGenerating = false;
    }

   public void OnClick()
    {
        transform.Rotate(0, 25 * Time.deltaTime, 0);

    }


}
