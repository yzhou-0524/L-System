﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class instimate : MonoBehaviour
{

    public GameObject obj; //传入的预设

    // Use this for initialization
    void Start()
    {
        //参数一：是预设 参数二：实例化预设的坐标  参数三：实例化预设的旋转角度
        GameObject instance = (GameObject)Instantiate(obj, transform.position, transform.rotation);
        //这里 transform.position，transform.rotation分别代表的是相机和坐标和 旋转角度

    }

    // Update is called once per frame
    void Update()
    {

    }

}
